
app_name = "beam_accounting"
app_title = "BEAM Accounting"
app_publisher = "Vivek Singh"
app_description = "Carbon modeling with ChatGPT assistant"
app_email = "vivek@example.com"
app_license = "MIT"
